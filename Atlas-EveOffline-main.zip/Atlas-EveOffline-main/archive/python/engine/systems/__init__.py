"""
Engine systems module
"""

from engine.systems.mining_system import MiningSystem

__all__ = ['MiningSystem']
