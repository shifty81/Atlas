"""
3D Client Package
Panda3D-based 3D client for EVE OFFLINE
"""

__version__ = "0.1.0"
__author__ = "EVE OFFLINE Development Team"
