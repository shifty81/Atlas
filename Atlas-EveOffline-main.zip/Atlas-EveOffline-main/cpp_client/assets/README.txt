Assets directory
