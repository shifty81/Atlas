#include "rendering/procedural_mesh_ops.h"
#include <algorithm>
#include <random>
#include <stdexcept>
#include <unordered_map>

namespace atlas {

// ────────────────────────────────────────────────────────────────────────
// Mathematical constants
// ────────────────────────────────────────────────────────────────────────
static constexpr float kPI = 3.14159265358979323846f;

// ────────────────────────────────────────────────────────────────────────
// PolyFace helpers
// ────────────────────────────────────────────────────────────────────────

void PolyFace::recalculateNormal() {
    if (outerVertices.size() < 3) return;
    glm::vec3 edge1 = outerVertices[1] - outerVertices[0];
    glm::vec3 edge2 = outerVertices[2] - outerVertices[0];
    glm::vec3 n = glm::cross(edge1, edge2);
    float len = glm::length(n);
    normal = (len > 1e-7f) ? n / len : glm::vec3(0.0f, 1.0f, 0.0f);
}

glm::vec3 PolyFace::centroid() const {
    glm::vec3 c(0.0f);
    if (outerVertices.empty()) return c;
    for (const auto& v : outerVertices) c += v;
    return c / static_cast<float>(outerVertices.size());
}

// ────────────────────────────────────────────────────────────────────────
// Polygon generation
// ────────────────────────────────────────────────────────────────────────

/**
 * Build a local 2D coordinate frame (tangent, binormal) on the plane
 * perpendicular to @p normal, then compute the polygon vertex at index @p i
 * for an N-sided polygon.
 *
 * Vertices are placed in clockwise winding order (negative index direction)
 * so that the resulting face normal points in the expected direction when
 * computed via cross product of the first two edges.
 */
static glm::vec3 computePolygonVertex(int i, int sides, float radius,
                                      float scaleX, float scaleZ,
                                      const glm::vec3& centre,
                                      const glm::vec3& tangent,
                                      const glm::vec3& binormal) {
    float angleStep = 2.0f * kPI / static_cast<float>(sides);
    float initialAngle = kPI / static_cast<float>(sides);
    // Negative index produces clockwise winding for correct face normal
    float angle = initialAngle + angleStep * static_cast<float>(-i - 1);
    float x = std::cos(angle) * radius * scaleX;
    float z = std::sin(angle) * radius * scaleZ;
    return centre + tangent * x + binormal * z;
}

/** Build a tangent/binormal frame for a given normal direction. */
static void buildTangentFrame(const glm::vec3& normal,
                              glm::vec3& tangent, glm::vec3& binormal) {
    glm::vec3 up = (std::abs(glm::dot(normal, glm::vec3(0, 1, 0))) < 0.99f)
                   ? glm::vec3(0, 1, 0) : glm::vec3(1, 0, 0);
    tangent  = glm::normalize(glm::cross(up, normal));
    binormal = glm::cross(normal, tangent);
}

PolyFace generatePolygonFace(int sides, float radius,
                             const glm::vec3& centre,
                             const glm::vec3& normal,
                             float scaleX, float scaleZ) {
    if (sides < 3) sides = 3;

    PolyFace face;
    face.normal = glm::normalize(normal);

    glm::vec3 tangent, binormal;
    buildTangentFrame(face.normal, tangent, binormal);

    face.outerVertices.reserve(sides);
    for (int i = 0; i < sides; ++i) {
        face.outerVertices.push_back(
            computePolygonVertex(i, sides, radius, scaleX, scaleZ,
                                 centre, tangent, binormal));
    }
    return face;
}

PolyFace generateIrregularPolygonFace(int sides,
                                      const std::vector<float>& radii,
                                      const glm::vec3& centre,
                                      const glm::vec3& normal,
                                      float scaleX, float scaleZ) {
    if (sides < 3) sides = 3;

    PolyFace face;
    face.normal = glm::normalize(normal);

    glm::vec3 tangent, binormal;
    buildTangentFrame(face.normal, tangent, binormal);

    face.outerVertices.reserve(sides);
    for (int i = 0; i < sides; ++i) {
        float r = (i < static_cast<int>(radii.size())) ? radii[i] : 1.0f;
        face.outerVertices.push_back(
            computePolygonVertex(i, sides, r, scaleX, scaleZ,
                                 centre, tangent, binormal));
    }
    face.recalculateNormal();
    return face;
}

// ────────────────────────────────────────────────────────────────────────
// Face extrusion
// ────────────────────────────────────────────────────────────────────────

PolyFace extrudeFace(const PolyFace& source, float distance,
                     float scale, const glm::vec3& direction) {
    glm::vec3 dir = (glm::length(direction) > 1e-7f)
                    ? glm::normalize(direction)
                    : source.normal;
    glm::vec3 offset = dir * distance;

    // Build a coordinate frame: the extrusion direction is the axis
    // along which vertices are NOT scaled.  Only the cross-section
    // (perpendicular) components are scaled.  With +Z as the hull
    // forward axis, X and Y (the cross-section) are scaled while Z
    // (the extrusion axis) is left unchanged.  This prevents compounding centroid
    // drift that produces "squiggly" hulls.
    glm::vec3 dirN = glm::normalize(dir);

    PolyFace extruded;
    extruded.outerVertices.reserve(source.outerVertices.size());
    for (const auto& v : source.outerVertices) {
        // Decompose vertex into component along extrusion axis and
        // component in the cross-section plane.
        float alongAxis = glm::dot(v, dirN);
        glm::vec3 crossSection = v - dirN * alongAxis;

        // Scale only the cross-section component
        glm::vec3 scaled = dirN * alongAxis + crossSection * scale;
        extruded.outerVertices.push_back(scaled + offset);
    }
    extruded.recalculateNormal();
    return extruded;
}

// ────────────────────────────────────────────────────────────────────────
// Face stitching
// ────────────────────────────────────────────────────────────────────────

std::vector<PolyFace> stitchFaces(const PolyFace& faceA, const PolyFace& faceB) {
    int n = faceA.sides();
    if (n != faceB.sides() || n < 3) return {};

    std::vector<PolyFace> quads;
    quads.reserve(n);
    for (int i = 0; i < n; ++i) {
        int j = (i + 1) % n;
        PolyFace quad;
        quad.outerVertices = {
            faceB.outerVertices[i],
            faceA.outerVertices[i],
            faceA.outerVertices[j],
            faceB.outerVertices[j],
        };
        quad.recalculateNormal();
        quads.push_back(std::move(quad));
    }
    return quads;
}

// ────────────────────────────────────────────────────────────────────────
// Bevel cut
// ────────────────────────────────────────────────────────────────────────

std::vector<PolyFace> bevelCutFace(const PolyFace& face,
                                   float borderSize, float depth) {
    if (face.sides() < 3) return {face};

    glm::vec3 cen = face.centroid();

    // Build the inner (inset) face
    PolyFace inner;
    inner.outerVertices.reserve(face.outerVertices.size());
    float insetFactor = 1.0f - std::clamp(borderSize, 0.0f, 1.0f);
    for (const auto& v : face.outerVertices) {
        inner.outerVertices.push_back(cen + (v - cen) * insetFactor);
    }
    // Push inner face along normal
    for (auto& v : inner.outerVertices) {
        v += face.normal * depth;
    }
    inner.recalculateNormal();

    // Build border quads between outer and inner rings
    int n = face.sides();
    std::vector<PolyFace> result;
    result.reserve(n + 1);
    for (int i = 0; i < n; ++i) {
        int j = (i + 1) % n;
        PolyFace quad;
        quad.outerVertices = {
            face.outerVertices[i],
            face.outerVertices[j],
            inner.outerVertices[j],
            inner.outerVertices[i],
        };
        quad.recalculateNormal();
        result.push_back(std::move(quad));
    }
    result.push_back(inner);
    return result;
}

// ────────────────────────────────────────────────────────────────────────
// Pyramidize
// ────────────────────────────────────────────────────────────────────────

std::vector<PolyFace> pyramidizeFace(const PolyFace& face, float height) {
    if (face.sides() < 3) return {face};

    glm::vec3 apex = face.centroid() + face.normal * height;
    int n = face.sides();
    std::vector<PolyFace> tris;
    tris.reserve(n);
    for (int i = 0; i < n; ++i) {
        int j = (i + 1) % n;
        PolyFace tri;
        tri.outerVertices = {
            face.outerVertices[i],
            face.outerVertices[j],
            apex,
        };
        tri.recalculateNormal();
        tris.push_back(std::move(tri));
    }
    return tris;
}

// ────────────────────────────────────────────────────────────────────────
// Subdivide face lengthwise (quads only)
// ────────────────────────────────────────────────────────────────────────

std::vector<PolyFace> subdivideFaceLengthwise(const PolyFace& face, int count) {
    if (face.sides() != 4 || count < 2) return {face};

    const auto& v = face.outerVertices;
    // v[0]─v[3] is "top" edge, v[1]─v[2] is "bottom" edge
    std::vector<PolyFace> strips;
    strips.reserve(count);
    for (int i = 0; i < count; ++i) {
        float t0 = static_cast<float>(i)     / static_cast<float>(count);
        float t1 = static_cast<float>(i + 1) / static_cast<float>(count);
        PolyFace strip;
        strip.outerVertices = {
            glm::mix(v[0], v[3], t0),
            glm::mix(v[1], v[2], t0),
            glm::mix(v[1], v[2], t1),
            glm::mix(v[0], v[3], t1),
        };
        strip.recalculateNormal();
        strips.push_back(std::move(strip));
    }
    return strips;
}

// ────────────────────────────────────────────────────────────────────────
// Bezier helpers
// ────────────────────────────────────────────────────────────────────────

glm::vec3 bezierLinear(const glm::vec3& a, const glm::vec3& b, float t) {
    return glm::mix(a, b, t);
}

glm::vec3 bezierQuadratic(const glm::vec3& a, const glm::vec3& b,
                          const glm::vec3& c, float t) {
    glm::vec3 ab = glm::mix(a, b, t);
    glm::vec3 bc = glm::mix(b, c, t);
    return glm::mix(ab, bc, t);
}

glm::vec3 bezierCubic(const glm::vec3& a, const glm::vec3& b,
                      const glm::vec3& c, const glm::vec3& d, float t) {
    glm::vec3 ab  = glm::mix(a, b, t);
    glm::vec3 bc  = glm::mix(b, c, t);
    glm::vec3 cd  = glm::mix(c, d, t);
    glm::vec3 abc = glm::mix(ab, bc, t);
    glm::vec3 bcd = glm::mix(bc, cd, t);
    return glm::mix(abc, bcd, t);
}

std::vector<glm::vec3> sampleBezierQuadratic(const glm::vec3& a,
                                             const glm::vec3& b,
                                             const glm::vec3& c,
                                             int intervals) {
    if (intervals < 1) intervals = 1;
    std::vector<glm::vec3> points;
    points.reserve(intervals + 1);
    for (int i = 0; i <= intervals; ++i) {
        float t = static_cast<float>(i) / static_cast<float>(intervals);
        points.push_back(bezierQuadratic(a, b, c, t));
    }
    return points;
}

// ────────────────────────────────────────────────────────────────────────
// Triangulation
// ────────────────────────────────────────────────────────────────────────

TriangulatedMesh triangulateFace(const PolyFace& face, const glm::vec3& color) {
    TriangulatedMesh mesh;
    int n = face.sides();
    if (n < 3) return mesh;

    // Compute a shared face normal
    glm::vec3 norm = face.normal;

    unsigned int baseIdx = 0;
    mesh.vertices.reserve(n);
    for (int i = 0; i < n; ++i) {
        Vertex v;
        v.position = face.outerVertices[i];
        v.normal   = norm;
        v.texCoords = glm::vec2(0.0f); // basic UV
        v.color    = color;
        mesh.vertices.push_back(v);
    }

    // Fan triangulation from vertex 0
    mesh.indices.reserve((n - 2) * 3);
    for (int i = 1; i < n - 1; ++i) {
        mesh.indices.push_back(baseIdx);
        mesh.indices.push_back(baseIdx + i);
        mesh.indices.push_back(baseIdx + i + 1);
    }
    return mesh;
}

TriangulatedMesh triangulateFaces(const std::vector<PolyFace>& faces,
                                  const glm::vec3& color) {
    TriangulatedMesh combined;
    for (const auto& face : faces) {
        TriangulatedMesh faceMesh = triangulateFace(face, color);
        unsigned int offset = static_cast<unsigned int>(combined.vertices.size());
        combined.vertices.insert(combined.vertices.end(),
                                 faceMesh.vertices.begin(),
                                 faceMesh.vertices.end());
        for (auto idx : faceMesh.indices) {
            combined.indices.push_back(offset + idx);
        }
    }
    return combined;
}

// ────────────────────────────────────────────────────────────────────────
// Radius multiplier generation
// ────────────────────────────────────────────────────────────────────────

// Empirical scaling factors from the reference project's Spaceship class.
// They control how quickly the max/min radius bounds grow with segment count,
// producing natural-looking hull taper and bulge variation.
static constexpr float kRadiusMaxGrowthRate = 0.1029f;
static constexpr float kRadiusMinGrowthRate = 0.0294f;
static constexpr float kRadiusMinFloor      = 0.5f;

std::vector<float> generateRadiusMultipliers(int segments, float baseRadius,
                                             unsigned int seed) {
    std::mt19937 rng(seed != 0 ? seed : 42u);
    std::uniform_real_distribution<float> dist(0.0f, 1.0f);

    float radiusMax = baseRadius * (kRadiusMaxGrowthRate * segments) + baseRadius;
    float radiusMin = baseRadius * (kRadiusMinGrowthRate * segments) + kRadiusMinFloor;

    std::vector<float> multipliers;
    multipliers.reserve(segments);
    float lastRadius = baseRadius;
    for (int i = 0; i < segments; ++i) {
        float newRadius = dist(rng) * (radiusMax - radiusMin) + radiusMin;
        multipliers.push_back(newRadius / lastRadius);
        lastRadius = newRadius;
    }
    return multipliers;
}

// ────────────────────────────────────────────────────────────────────────
// Segmented hull builder
// ────────────────────────────────────────────────────────────────────────

// ────────────────────────────────────────────────────────────────────────
// Internal helpers for nose, thruster and detail generation
// (following the reference project's Spaceship.generate_nose,
//  generate_thrusters and add_detail_to_faces approach)
// ────────────────────────────────────────────────────────────────────────

/**
 * Generate a tapered nose cone by extruding from the front face.
 * Mimics the reference project's generate_nose():
 *   - Extrude forward by a random distance (0.25-1.5x segmentLength)
 *   - Scale down to 10-30% of the face radius
 *   - Stitch walls between original and tapered face
 *   - Add the tapered cap face
 */
static void generateNose(const PolyFace& frontFace, float segmentLength,
                          std::mt19937& rng,
                          std::vector<PolyFace>& outFaces) {
    std::uniform_real_distribution<float> dist01(0.0f, 1.0f);
    float noseLength = segmentLength * (0.25f + dist01(rng) * 1.25f);
    float noseScale  = dist01(rng) * 0.2f + 0.1f;

    // The front face normal points away from the hull base.
    // The nose extends in that same direction (outward/forward).
    glm::vec3 noseDir = -frontFace.normal;

    PolyFace noseTip = extrudeFace(frontFace, noseLength, noseScale, noseDir);

    // Stitch from the nose tip to the original front face
    auto walls = stitchFaces(noseTip, frontFace);
    outFaces.insert(outFaces.end(), walls.begin(), walls.end());

    // Reversed cap (nose tip, facing outward)
    PolyFace cap = noseTip;
    std::reverse(cap.outerVertices.begin(), cap.outerVertices.end());
    cap.recalculateNormal();
    outFaces.push_back(cap);
}

/**
 * Generate thruster recesses in the rear face using recursive bevel cuts.
 * Mimics the reference project's generate_thrusters():
 *   - Bevel out a small ridge (0.25x segmentLength)
 *   - Bevel in to create exhaust cavity (-0.5x segmentLength)
 */
static void generateThrusters(const PolyFace& rearFace, float segmentLength,
                               std::vector<PolyFace>& outFaces) {
    // First bevel: slight outward ridge
    auto firstBevel = bevelCutFace(rearFace, 0.25f, segmentLength * 0.25f);
    if (firstBevel.empty()) { outFaces.push_back(rearFace); return; }

    PolyFace innerAfterFirst = firstBevel.back();
    firstBevel.pop_back();
    outFaces.insert(outFaces.end(), firstBevel.begin(), firstBevel.end());

    // Second bevel: deep inward recess for thruster cavity
    auto secondBevel = bevelCutFace(innerAfterFirst, 0.5f, -segmentLength * 0.5f);
    outFaces.insert(outFaces.end(), secondBevel.begin(), secondBevel.end());
}

/**
 * Apply symmetric surface details to the wall faces of the hull.
 * Mimics the reference project's add_detail_to_faces():
 *   - Group faces by segment and apply matched operations for symmetry
 *   - Operations chosen by random instruction value:
 *     < 0.25: subdivide + bevel cubbies
 *     < 0.5:  pyramidize
 *     < 0.75: bevel recess
 *     else:   leave plain
 */
static void applyWallDetails(const std::vector<PolyFace>& wallFaces,
                              int sides, int segments,
                              std::mt19937& rng,
                              std::vector<PolyFace>& outFaces) {
    std::uniform_real_distribution<float> dist01(0.0f, 1.0f);

    // Determine symmetry type (matching the reference)
    int pairsPerSegment = (sides % 2 == 0) ? sides / 2 : sides;

    // Generate per-segment instructions
    std::vector<std::vector<float>> instructions(segments);
    for (int s = 0; s < segments; ++s) {
        instructions[s].resize(pairsPerSegment);
        for (int p = 0; p < pairsPerSegment; ++p) {
            instructions[s][p] = dist01(rng);
        }
    }

    for (int s = 0; s < segments; ++s) {
        for (int i = 0; i < sides; ++i) {
            int faceIdx = s * sides + i;
            if (faceIdx >= static_cast<int>(wallFaces.size())) break;

            const PolyFace& face = wallFaces[faceIdx];
            // Determine which instruction applies (symmetric pairing)
            int instrIdx = (sides % 2 == 0) ? (i % pairsPerSegment) : i;
            float instr = instructions[s][instrIdx];

            if (instr < 0.25f) {
                // Subdivide + bevel cubbies
                auto strips = subdivideFaceLengthwise(face, 2);
                for (const auto& strip : strips) {
                    auto cubby = bevelCutFace(strip, 0.5f, -0.33f);
                    outFaces.insert(outFaces.end(), cubby.begin(), cubby.end());
                }
            } else if (instr < 0.5f) {
                // Pyramidize for aggressive surface detail
                auto pyra = pyramidizeFace(face, 0.15f);
                outFaces.insert(outFaces.end(), pyra.begin(), pyra.end());
            } else if (instr < 0.75f) {
                // Bevel recess
                auto bevel = bevelCutFace(face, 0.25f, -0.2f);
                outFaces.insert(outFaces.end(), bevel.begin(), bevel.end());
            } else {
                // Leave plain
                outFaces.push_back(face);
            }
        }
    }
}

TriangulatedMesh buildSegmentedHull(int sides, int segments,
                                    float segmentLength, float baseRadius,
                                    const std::vector<float>& radiusMultipliers,
                                    float scaleX, float scaleZ,
                                    const glm::vec3& color) {
    // The hull is built along the +Z axis (forward direction),
    // matching the game's coordinate convention where +Z is forward,
    // +Y is up, and rotation happens around Y.
    glm::vec3 fwd(0.0f, 0.0f, 1.0f);
    glm::vec3 centre(0.0f);

    PolyFace baseFace = generatePolygonFace(sides, baseRadius, centre, fwd,
                                            scaleX, scaleZ);

    // Keep track of all cross-section rings for stitching
    std::vector<PolyFace> rings;
    rings.reserve(segments + 1);
    rings.push_back(baseFace);

    std::vector<PolyFace> wallFaces;    // stitched wall quads

    PolyFace previous = baseFace;

    for (int i = 0; i < segments; ++i) {
        float mult = (i < static_cast<int>(radiusMultipliers.size()))
                     ? radiusMultipliers[i] : 1.0f;

        // Extrude produces the next cross-section ring
        PolyFace next = extrudeFace(previous, segmentLength, mult, fwd);

        // Stitch the walls between the two rings
        auto walls = stitchFaces(previous, next);
        wallFaces.insert(wallFaces.end(), walls.begin(), walls.end());

        rings.push_back(next);
        previous = next;
    }

    // Determine a seed for detail RNG (use first multiplier bits or fallback)
    unsigned int detailSeed = 42u;
    if (!radiusMultipliers.empty()) {
        union { float f; unsigned int u; } conv;
        conv.f = radiusMultipliers[0];
        detailSeed = conv.u;
    }
    std::mt19937 detailRng(detailSeed);

    // -- Collect all output faces --
    std::vector<PolyFace> allFaces;
    allFaces.reserve(wallFaces.size() + sides * 4 + 2);

    // 1. Apply surface details to wall faces (matching reference approach)
    applyWallDetails(wallFaces, sides, segments, detailRng, allFaces);

    // 2. Generate nose from the first (front) face
    generateNose(rings.front(), segmentLength, detailRng, allFaces);

    // 3. Generate thrusters on the last (rear) face
    generateThrusters(rings.back(), segmentLength, allFaces);

    TriangulatedMesh result = triangulateFaces(allFaces, color);
    computeSmoothNormals(result);
    return result;
}

// ────────────────────────────────────────────────────────────────────────
// Smooth normal computation
// ────────────────────────────────────────────────────────────────────────

void computeSmoothNormals(TriangulatedMesh& mesh, float epsilon) {
    if (mesh.vertices.empty() || mesh.indices.empty()) return;

    // Spatial hash: bucket vertices by quantised position so that
    // coincident vertices (within epsilon) share averaged normals.
    // This turns flat-shaded meshes into smooth-shaded ones.

    auto quantise = [epsilon](const glm::vec3& p) -> uint64_t {
        float inv = 1.0f / std::max(epsilon, 1e-7f);
        int32_t ix = static_cast<int32_t>(std::floor(p.x * inv));
        int32_t iy = static_cast<int32_t>(std::floor(p.y * inv));
        int32_t iz = static_cast<int32_t>(std::floor(p.z * inv));
        // Simple spatial hash combining the three quantised coords
        uint64_t h = static_cast<uint64_t>(ix * 73856093u);
        h ^= static_cast<uint64_t>(iy * 19349663u);
        h ^= static_cast<uint64_t>(iz * 83492791u);
        return h;
    };

    // Phase 1: accumulate face normals per spatial bucket
    std::unordered_map<uint64_t, glm::vec3> accum;
    accum.reserve(mesh.vertices.size());

    // Walk triangles and accumulate face normals at each vertex bucket
    size_t triCount = mesh.indices.size() / 3;
    for (size_t t = 0; t < triCount; ++t) {
        unsigned int i0 = mesh.indices[t * 3 + 0];
        unsigned int i1 = mesh.indices[t * 3 + 1];
        unsigned int i2 = mesh.indices[t * 3 + 2];
        const glm::vec3& p0 = mesh.vertices[i0].position;
        const glm::vec3& p1 = mesh.vertices[i1].position;
        const glm::vec3& p2 = mesh.vertices[i2].position;

        glm::vec3 faceNormal = glm::cross(p1 - p0, p2 - p0);
        float len = glm::length(faceNormal);
        if (len > 1e-7f) faceNormal /= len;

        accum[quantise(p0)] += faceNormal;
        accum[quantise(p1)] += faceNormal;
        accum[quantise(p2)] += faceNormal;
    }

    // Phase 2: normalise accumulated normals and write back to vertices
    for (auto& v : mesh.vertices) {
        auto it = accum.find(quantise(v.position));
        if (it != accum.end()) {
            float len = glm::length(it->second);
            v.normal = (len > 1e-7f) ? it->second / len
                                      : glm::vec3(0.0f, 1.0f, 0.0f);
        }
    }
}

} // namespace atlas
